# About Sports Partner

## What is it?
It is a tool for people who can not do some execrise alone to find a Partner to do the execrise together.
For example, basketball players can use this to find someone else also interested in basketball and organize a race.

## How can this happen?
We gather the information from the users.
Include:
- Their name
- Sex
- Age
- Address
- Education
- Which sports they like to do
- The skill degree